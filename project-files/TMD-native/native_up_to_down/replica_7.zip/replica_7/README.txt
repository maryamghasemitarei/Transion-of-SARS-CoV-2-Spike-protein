This folder containes:
1- the folder named "toppar" contains the bonded and non-bonded parameters of atoms in charmm36 force field.
2- the topology file named "topol". 
3- the configuration file named "initial" contains the coordinates of all atoms in the system, including the SARS-CoV-2 spike protein, glycans, water molecules, and ions in their initial state.
4- the configuration files named "chain_A", "chain_B" and "chain_C" contain the atomic coordinates of the final structures for only chain A, chain B, and chain C of the SARS-CoV-2 spike protein, respectively.
5- the configuration files named "gly" contain the atomic coordinates of the final structures for all glycans of the SARS-CoV-2 spike protein.
6- the configuration files named "protein" contain the atomic coordinates of the final structures for  the SARS-CoV-2 spike protein without glycans.
7- the configuration files named "final" contain the atomic coordinates of the final structures for the SARS-CoV-2 spike protein with glycans.


Any sub-folders has its own README file.
