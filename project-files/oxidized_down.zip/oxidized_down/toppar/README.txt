This folder containes:
1- the files contains the bonded and non-bonded parameters of atoms in charmm36 forcefield.
2- the file named "PROA" contains the parameters for chain A of the SARS-CoV-2 spike protein in its oxidized form.
3- the file named "PROB" contains the parameters for chain B of the SARS-CoV-2 spike protein in its oxidized form.
4- the file named "PROC" contains the parameters for chain C of the SARS-CoV-2 spike protein in its oxidized form.
