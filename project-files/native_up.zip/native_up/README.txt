This folder containes:
1- the folder named "toppar" contains the bonded and non-bonded parameters of atoms in charmm36 force field.
2- the topology file named "topol". 
3- the index file named "index" contains some user definable sets of atoms.
4- the configuration file named "native_up" contains the coordinates of all atoms of system, including up conformation of SARS-CoV-2 spike protein in the native form, water molecules and ions.

Any sub-folders has its own README file.
